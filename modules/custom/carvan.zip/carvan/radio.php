<?php
//**********Create shortcode and Display Posts according to shortcode**************
if ( !function_exists( 'display_list_of_post' ) ) {
   function display_list_of_post($atts = ''){
      ob_start();
      global $wp_query;
      $post_per_page       = get_option('post-page');
      $feature_image_opt   = implode('',(get_option('my_option')));
      $read_more1          = implode('',(get_option('rm_option')));
      $post_type_opt       = get_option('select1');
      $paged=( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
      // define attributes and their defaults
      extract( shortcode_atts( array (
            'post_per_page1' => $post_per_page,
            'read_more'=> $read_more1,
            'feature_image'=>$feature_image_opt,
            'post_type'=>$post_type_opt,
       ), $atts ) );
      // define query parameters based on attributes
      $args= array(
               'post_type'=> $post_type,
               'order_by' => 'menu_order',
               'order'    => 'ASC',
               'posts_per_page' => $post_per_page1,
               'paged' => $paged
            );
            $db_query =new WP_Query($args);
               while( $db_query->have_posts() ) : $db_query->the_post(); ?>
                  <div class="blog-post">
                     <h3 class="blog-post-title"><a href="<?php the_permalink(); ?>">
                        <?php the_title(); ?></a>
                     </h3>
                     <?php if ( $feature_image =="yes" && has_post_thumbnail() ) {?>
                        <div class="row">
                           <div class="col-md-4">
                              <?php the_post_thumbnail('medium'); ?>
                           </div>
                           <div class="col-md-8">
                              <?php if($read_more =='yes')
                              the_excerpt();
                              else
                              the_content(); ?>
                           </div>
                        </div>
                        <?php 
                        } else { ?>
                           <?php 
                              if($read_more =='yes')
                                 the_excerpt();
                              else
                                 the_content();
                              }
                           ?>
                           <div id="modal-<?php the_ID();?>" class="modal fade modal-<?php the_ID();?>" role="dialog">
                             <div class="modal-dialog">
                               <!-- Modal content-->
                               <div class="modal-content">
                                 <div class="modal-header">
                                   <button type="button" class="close" data-dismiss="modal">&times;</button>
                                   <h4 class="modal-title"><?php the_title(); ?></h4>
                                 </div>
                                 <div class="modal-body">
                                    <?php the_post_thumbnail('medium'); ?>
                                 <?php the_content();?>
                                 </div>
                               </div>
                             </div>
                           </div>
               <?php endwhile;?>
               <?php  
               $big = 999999; // need an unlikely integer
               echo paginate_links( array(
                  'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                  'format' => '?paged=%#%',
                  'current' => max( 1, get_query_var('paged') ),
                  'total' => $db_query->max_num_pages
               ) );
               ?>
            </div>
      <?php
         return ob_get_clean();
   }
}
add_shortcode( 'list-posts', 'display_list_of_post' );