<?php
/**
 * @package Carvan
 * @version 1.0.0
 * @copyright Neosoft Technologies
 * @license GPL-2.0-or-later
 * @author Paurnima Savkare. 
 */
/*
Plugin Name: Amazon Carvaan
Plugin URI: http://example.com/carvan-uri/
description: A plugin used to create admin form to get the details
Version: 1.7.2
Author: Ms. Paurnima Savkare
Author URI: http://mrtotallyawesome.com
License: GPL2
*/
/*function carvan_script   s(){
   wp_enqueue_script('custom-js', plugin_dir_url(__FILE__) . 'script.js', array('jquery'),1.1,true);
}*/
if (! defined('ABSPATH')) 
   exit;
/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */

include_once plugin_dir_path( __FILE__ ) . 'radio.php'; 
define( 'CARVAN_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-plugin-name-activator.php
 */
function activate_carvan() {
   require_once plugin_dir_path( __FILE__ ) . 'includes/class-carvan-activator.php';
   Plugin_Name_Activator::activate();
}
/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-plugin-name-deactivator.php
 */
function deactivate_carvan() {
   require_once plugin_dir_path( __FILE__ ) . 'includes/class-carvan-deactivator.php';
   Plugin_Name_Deactivator::deactivate();
}
register_activation_hook( __FILE__, 'activate_carvan' );
register_deactivation_hook( __FILE__, 'deactivate_carvan' );

function carvan_init() {
    wp_enqueue_script( 'carvan-js',plugin_dir_url(__FILE__) . '/custom-js.js', array('jquery'),1.1,true);
}
add_action( 'wp_enqueue_scripts', 'carvan_init' );


function test_plugin_setup_menu(){
        add_menu_page( 'Display Form Settings', 'Display Form', 'manage_options', 'form-plugin', 'form_custom_function' );
}
if ( is_admin() ){ // admin actions
  add_action( 'admin_menu', 'test_plugin_setup_menu' );
  add_action( 'admin_init', 'custom_settings_page_setup1' );
} else {
  // non-admin enqueues, actions, and filters
}
function form_custom_function() { ?>
   <div class="wrap">
      <h1>Custom Settings</h1>
      <form method="post" action="options.php">
         <?php
            settings_fields( 'myoption-group' );
            do_settings_sections( 'custom-option' );
            //submit_button();
         ?>
         <input type="submit" name="submit" id="submit_form" class="button button-primary" value="Save Changes"  />
        <!-- <button type="submit" class="button button-primary" name="submit" onclick="myFunction()">Save Changes</button> -->
      <?php
         $post_per_page       = get_option('post-page');
         $feature_image_opt   = implode('',(get_option('my_option')));
         $read_more1          = implode('',(get_option('rm_option')));
         $post_type_opt       = get_option('select1');
         if (isset($_GET['settings-updated']) && !( $post_type_opt =="0") && !($post_per_page =="0")) :?>
         <div class="notice notice-success">
         <?php echo '<p>Your Shortcode will be [list-posts post_per_page="'.$post_per_page.'" feature_image ="'.$feature_image_opt.'" read_more="'.$read_more1.'" post_type="'.$post_type_opt.'"]</p></div>';
         ?>
         </div>
         <?php endif; ?>
      </form>
   </div>   
<?php }
//*************************Posts Per Page Field************************
function post_per_page_option(){ 
   $post_page = get_option('post-page');?>
   <input type="number" id="post-page" name= post-page min="-1" max="9" 
   value="<?php echo $post_page ? : "-1" ; ?>" />
<?php }
//*********************Feature Image field********************************
function featured_image_option(){ 
   $options = get_option( 'my_option' );?>
   <input type="radio" name="my_option[feature_image]" value= "yes" <?php checked( "yes" == $options['feature_image'] );?> checked>Yes
   <input type="radio" name="my_option[feature_image]" value= "no" <?php checked( "no" == $options['feature_image'] );?> />No
<?php }
//********************Read More Field***************************************
function read_more_option(){ 
   $options = get_option( 'rm_option' );?>
   <input type="radio" name="rm_option[read_more]" value="yes" <?php checked( "yes" == $options['read_more'] );?> checked>Yes
   <input type="radio" name="rm_option[read_more]" value="no" <?php checked( "no" == $options['read_more'] );?> />No
<?php }
//**********************Custom Post Type Select Field***********************
function custom_post_type_option() {
     $args = array(
         'public'   => true,
         '_builtin' => false
      );
      $output = 'names'; // names or objects, note names is the default
      $operator = 'and'; // 'and' or 'or'
      $post_types = get_post_types( $args, $output, $operator );
      $check = get_option( 'select1');
      if($check=="0"){
         echo "<div class='notice notice-error'>Please select Post Type</div>";
      }?>
      <select id="select1" name="select1" >
      <option value="0">--select--</option> 
      <?php foreach ( $post_types  as $post_type ) { 
         $check = get_option( 'select1');?>
         <option value="<?php echo $post_type ?>" <?php if (!empty($check) && $check == $post_type)echo 'selected = "selected"'; ?>><?php echo $post_type ?></option>;
      <?php } ?>
      </select>
<?php }

//********Register the fields to the menu page***********************************
function custom_settings_page_setup1() {
   add_settings_section( 'myoption-group', 'Display Settings', null, 'custom-option' );
   //add_settings_field( 'twitter1', 'Twitter URL', 'setting_twitter1', 'custom-option', 'myoption-group' );
   add_settings_field('post-page', 'Post Per Page', 'post_per_page_option','custom-option','myoption-group');
   add_settings_field('my_option', 'Featured Image', 'featured_image_option','custom-option','myoption-group');
   add_settings_field('rm_option', 'Read More', 'read_more_option','custom-option','myoption-group');
   add_settings_field( 'select1', 'Custom Post type Options', 'custom_post_type_option', 'custom-option', 'myoption-group' );
   register_setting('myoption-group', 'select1');
   register_setting('myoption-group', 'rm_option');
   register_setting('myoption-group','post-page');
   register_setting('myoption-group','my_option');
}
?>