<?php
if ( !function_exists( 'user_details_form' ) ) {
	function user_details_form(){ 
		$fnameErr = $lnameErr = $emailErr = $mobileErr = "";
		$fname =$lname = $email = $mobile= "";
		$errors=array();
	    if ( $_SERVER["REQUEST_METHOD"] == "POST") 
	    {
	    	if (empty($_POST["sa-fname"]))
	    	{
	    		$errors['fname'] = "First Name is required";
			}
			else
			{
			    $fname = test_input($_POST["sa-fname"]);
			    // check if name only contains letters and whitespace
			    if (!preg_match("/^[a-zA-Z ]*$/",$fname)) {
			      $errors['fname'] = "Only letters and white space allowed"; 
			    }
			}
			if (empty($_POST["sa-lname"]))
			{
		    	$errors['lname'] = "Last Name is required";
			}else
			{
			    $lname = test_input($_POST["sa-lname"]);
			    // check if name only contains letters and whitespace
			    if (!preg_match("/^[a-zA-Z ]*$/",$lname)) {
			      $errors['lname']= "Only letters and white space allowed"; 
			    }
			}
			if(empty($_POST["sa-email"]))
			{
				$errors['email']="Email is required";
			}else
			{
				$email=test_input($_POST["sa-email"]);
				if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			      	$errors['email'] = "Invalid email format"; 
			    }
			}
			if(empty($_POST["sa-mobile"]))
			{
				$errors['mobile']="Mobile no. is required";
			}else
			{
				$mobile=test_input($_POST["sa-mobile"]);
				if (!preg_match('/^[0-9]{10}+$/', $mobile)){
			      	$errors['mobile'] = "Mobile no. is not valid"; 
			    }
			}
			if(!$errors){
				echo "Your form submitted successfully";
				global $wpdb;
		        $tablename = $wpdb->prefix.'saavn';
		        $query=$wpdb->insert( $tablename, array(
		        	'f_name' 	=> $fname,
		        	'l_name' 	=> $lname,
		        	'email' 	=> $email,
		        	'mobile' 	=> $mobile,
		        	'address' 	=> $_POST['sa-location'] ),
		            array( '%s', '%s', '%s', '%s', '%s')
		        );
		       /* mysql_query($query);*/
			}
			
		}?>	    
		<form id="custom-form" action="<?php echo $_SERVER['REQUEST_URI'] ?>" method="post">
	 	<div>
	    <label for="firstname">First Name <strong>*</strong></label>
	    <input type="text" name="sa-fname"  id="fname" value="">
	    <span class="error"><?php if(isset($errors['fname'])) echo $errors['fname']  ?>
	    </div>

	    <div>
	    <label for="lastname">Last Name<strong>*</strong></label>
	    <input type="text" name="sa-lname"  id="lname" value="">
	    <span class="error"><?php if(isset($errors['lname'])) echo $errors['lname']  ?>

	    </div>

	    <div>
	    <label for="email">Email <strong>*</strong></label>
	    <input type="text" name="sa-email" value="" >
	    <span class="error"><?php if(isset($errors['email'])) echo $errors['email']  ?></span>
	    </div>
	     
	    <div>
	    <label for="mobile">Mobile No.<strong>*</strong></label>
	    <input type="text" name="sa-mobile" value="">
	    <span class="error"><?php if(isset($errors['mobile'])) echo $errors['mobile']  ?></span>
	    </div>

	    <div>
	    <label for="location">location</label>
	    <textarea form="custom-form" name="sa-location" value=""></textarea>
	    </div>
	     
	    <input type="submit" name="submit" value="save"/>
	    </form>
	    <?php
    	 } 
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
function saavn_shortcode() {
    ob_start();
   // form_submission();
    user_details_form();
    return ob_get_clean();
}
add_shortcode( 'saavn_user_form', 'saavn_shortcode' );
?>