<?php
    /**
    * PART 1. Defining Custom Table List
    * ============================================================================
    * In this part you are going to define custom table list class,
    * that will display your database records in nice looking table
    */
    if (! defined('ABSPATH')) 
        exit;
    if (!class_exists('WP_List_Table')) {
        require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
    }
    if (isset($_GET['action']) && $_GET['action'] == 'edit') {
            $id = $_REQUEST['application_id'];
            $sad=edit_form($id);
            echo $sad;
    }
    if (isset($_GET['action']) && $_GET['action'] == 'delete') {
            delete_form();
    }
    function edit_form($id){
       global $wpdb;
       $table_name = $wpdb->prefix . 'saavn';
       $thepost = $wpdb->get_row("SELECT * FROM $table_name WHERE $id = id" );
       if($thepost){
           $f_name  = $thepost->f_name;
           $l_name  = $thepost->l_name;
           $address = $thepost->address;
           $mobile  = $thepost->mobile;
           $email   = $thepost->email;
       }
       if(isset($_POST['update'])){
            $id         = $_REQUEST['application_id'];
            $fname      = sanitize_text_field( $_POST["sa-fname"] );
            $lname      = sanitize_text_field( $_POST["sa-lname"] );
            $email      = sanitize_email( $_POST["sa-email"] );
            $mobile     = sanitize_text_field( $_POST["sa-mobile"] );
            $address    = esc_textarea( $_POST["sa-location"] );
            $url        = $_SERVER['REQUEST_URI'].'?page=applications';
            $where = [ 'id' => $id ];
            $data=array(
                    'f_name'    => $fname,
                    'l_name'    => $lname,
                    'email'     => $email,
                    'mobile'    => $mobile,
                    'address'   => $address );
            $result=$wpdb->update( $table_name, $data, $where );
            return $result;
        }else{
                /*echo "First Name :".$f_name."Last Name : ".$l_name."Address :".$address." Mobile Number : ".$mobile."Email :".$email;*/
            echo '    
                <form id="custom-form" method="post">
                <div>
                <label for="firstname">First Name <strong>*</strong></label>
                <input type="text" name="sa-fname" value="'.$f_name.'">
                </div>
                <div>
                <label for="lastname">Last Name</label>
                <input type="text" name="sa-lname" value="'.$l_name.'">
                </div>

                <div>
                <label for="email">Email <strong>*</strong></label>
                <input type="text" name="sa-email" value="'.$email.'" required>
                </div>
                 
                <div>
                <label for="mobile">Mobile No.</label>
                <input type="text" name="sa-mobile" value="'.$mobile.'">
                </div>

                <div>
                <label for="location">location</label>
                <textarea form="custom-form" name="sa-location" value="">'.htmlspecialchars($address) .'</textarea>
                </div>
                 
                <input type="submit" name="update" value="Update"/>
                </form>
            ';
        }
    }
    function delete_form(){
        $id= $_REQUEST['application_id'];
        global $wpdb;
        $table_name = $wpdb->prefix . 'saavn';
        $result= $wpdb->delete(
            "$table_name",
            [ 'id' => $id ],
            [ '%d' ]
          );
        return $result;
    }
    /**
    * custom_form_example_List_Table class that will display our custom table
    * records in nice table
    */
class custom_form_example_List_Table extends WP_List_Table
{
    /**
    * [REQUIRED] You must declare constructor and give some basic params
    */
    function __construct()
    {
        global $status,$page;
        parent::__construct(array(
            'singular' => 'application',
            'plural' => 'applications',
        ));
    }
    /**
    * [REQUIRED] this is a default column renderer
    *
    * @param $item - row (key, value array)
    * @param $column_fname - string (key)
    * @return HTML
    */
    function column_default($item, $column_name)
    {
        return $item[$column_name];
    }
    /**
    * [OPTIONAL] this is example, how to render specific column
    *
    * method name must be like this: "column_[column_fname]"
    *
    * @param $item - row (key, value array)
    * @return HTML
    */
    function column_f_name($item)
    {
        // links going to /admin.php?page=[your_plugin_page][&other_params]
        // notice how we used $_REQUEST['page'], so action will be done on current page
        // also notice how we use $this->_args['singular'] so in this example it will
        // be something like &person=2
        //$delete_nonce = wp_create_nonce( 'sp_delete_customer' );
        $actions = array(
            'edit'      => sprintf('<a href="?page=form&action=%s&application_id=%s">Edit</a>','edit',$item['id']),
            'delete'    => sprintf('<a href="?page=%s&action=%s&application_id=%s">Delete</a>',$_REQUEST['page'],'delete',$item['id'] ),

        );
        return sprintf('%1$s %2$s', $item['f_name'], $this->row_actions($actions) );
    }
    /**
    * [REQUIRED] this is how checkbox column renders
    * @param $item - row (key, value array)
    * @return HTML
    */
    function column_cb($item)
    {
        return sprintf(
            '<input type="checkbox" name="id[]" value="%s" />',
            $item['id']
        );
    }
    /**
    * [REQUIRED] This method return columns to display in table
    * you can skip columns that you do not want to show
    * like content, or description
    * @return array
    */
    function get_columns()
    {
        $columns = array(
            'cb'        =>  '<input type="checkbox" />', //Render a checkbox instead of text
            'f_name'    =>  __('First Name', 'custom_form_example'),
            'l_name'    =>  __('Last Name', 'custom_form_example'),
            'email'     =>  __('E-Mail', 'custom_form_example'),
            'mobile'    =>  __('Mobile', 'custom_form_example'),
            'address'   =>  __('Address', 'custom_form_example'),
        );
        return $columns;
    }
    /**
    * [OPTIONAL] This method return columns that may be used to sort table
    * all strings in array - is column names
    * notice that true on name column means that its default sort
    *
    * @return array
    */
    function get_sortable_columns()
    {
        $sortable_columns = array(
            'f_name'    => array(  'f_name',   true  ),
            'l_name'    => array(  'l_name',   true  ),
            'email'     => array(  'email',    false ),
        );
        return $sortable_columns;
    }
    /**
    * [OPTIONAL] Return array of bult actions if has any
    *
    * @return array
    */
    function get_bulk_actions()
    {
        $actions = array(
            'bulk-delete' => 'Delete'
        );
        return $actions;
    }
    /**
    * [OPTIONAL] This method processes bulk actions
    * it can be outside of class
    * it can not use wp_redirect coz there is output already
    * in this example we are processing delete action
    * message about successful deletion will be shown on page in next part
    */
    function process_bulk_action()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'saavn'; // do not forget about tables prefix
        $result='';
        if ('bulk-delete' === $this->current_action()) {
            $ids = isset($_REQUEST['id']) ? $_REQUEST['id'] : array();
            if (is_array($ids)) $ids = implode(',', $ids);

            if (!empty($ids)) {
                $result =$wpdb->query("DELETE FROM $table_name WHERE id IN($ids)");
                if($result)
                {
                    $message = '<div class="updated below-h2" id="message"><p>' . sprintf(__('Items deleted : %d', 'custom_form_example'), $result) . '</p></div>';
                    echo $message;
                }
            }
        }
        
    }
    /**
    * [REQUIRED] This is the most important method
    * It will get rows from database and prepare them to be showed in table
    */
    function prepare_items()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'saavn'; // do not forget about tables prefix
        $per_page = 7; // constant, how much records will be shown per page
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        // here we configure table headers, defined in our methods
        $this->_column_headers = array($columns, $hidden, $sortable);
        // [OPTIONAL] process bulk action if any
        $this->process_bulk_action();
        // will be used in pagination settings
        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");
        // prepare query params, as usual current page, order by and order direction
        $paged = isset($_REQUEST['paged']) ? ($per_page * max(0, intval($_REQUEST['paged']) - 1)) : 0;
        $orderby = (isset($_REQUEST['orderby']) && in_array($_REQUEST['orderby'], array_keys($this->get_sortable_columns()))) ? $_REQUEST['orderby'] : 'f_name';
        $order = (isset($_REQUEST['order']) && in_array($_REQUEST['order'], array('asc', 'desc'))) ? $_REQUEST['order'] : 'asc';
        // [REQUIRED] define $items array
        // notice that last argument is ARRAY_A, so we will retrieve array
        $this->items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name ORDER BY $orderby $order LIMIT %d OFFSET %d", $per_page, $paged), ARRAY_A);
        // [REQUIRED] configure pagination
        $this->set_pagination_args(array(
            'total_items'   => $total_items, // total items defined above
            'per_page'      => $per_page, // per page constant defined at top of method
            'total_pages'   => ceil($total_items / $per_page) // calculate pages count
        ));
    }
}
/**
* PART 3. Admin page
* ============================================================================
*
* In this part you are going to add admin page for custom table
*
* http://codex.wordpress.org/Administration_Menus
*/
/**
* admin_menu hook implementation, will add pages to list applications and to add new one
*/
function custom_form_example_admin_menu()
{
    add_menu_page(__('Applications', 'custom_form_example'), __('Applications', 'custom_form_example'), 'activate_plugins', 'applications', 'custom_form_example_application_handler');
    /*add_submenu_page('applications', __('Applications', 'custom_form_example'), __('Applications', 'custom_form_example'), 'activate_plugins', 'applications', 'custom_form_example_application_handler');*/
    // add new will be described in next part
}
add_action('admin_menu', 'custom_form_example_admin_menu');
/**
* List page handler
* This function renders our custom table
* Notice how we display message about successfull deletion
* Actualy this is very easy, and you can add as many features
* as you want.
* Look into /wp-admin/includes/class-wp-*-list-table.php for examples
*/
function custom_form_example_application_handler()
{
    global $wpdb;
    $table = new custom_form_example_List_Table();
    $table->prepare_items();
    $message = '';
    $count=0;
    if ('delete' === $table->current_action()) {
        $count++;
        $message = '<div class="updated below-h2" id="message"><p>' . sprintf(__('Items deleted : %d', 'custom_form_example'), $count) . '</p></div>';
    }
    ?>
    <div class="wrap">
        <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
        <h2><?php _e('Applications', 'custom_form_example')?></h2>
        <?php echo $message; ?>
        <form id="applications-table" method="GET">
            <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>"/>
            <?php $table->display() ?>
        </form>
    </div>
<?php
}
?>