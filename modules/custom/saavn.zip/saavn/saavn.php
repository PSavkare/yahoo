<?php
/**
 * @package Saavn
 * @version 1.0.0
 * @copyright Neosoft Technologies
 * @license GPL-2.0-or-later
 * @author Paurnima Savkare. 
 */
/*
Plugin Name: Saavn
Plugin URI: http://example.com/saavn-uri/
description: A plugin used to Create form and admin dashboard for it.
Version: 1.0.0
Author: Ms. Paurnima Savkare
Author URI: http://mrtotallyawesome.com
License: GPL2
*/
function saavn_admin_init() {
	wp_register_style('saavn-styles', '/wp-content/plugins/saavn/saavn-styles.css');
}
function saavn_admin_style() {
	wp_enqueue_style('saavn-styles');
}
add_action('admin_init', 'saavn_admin_init');
add_action('admin_print_styles', 'saavn_admin_style');
if (! defined('ABSPATH')) 
   exit;
/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
//include_once plugin_dir_path( __FILE__ ) . 'radio.php'; 
define( 'SAAVN_VERSION', '1.0.0' );
include_once plugin_dir_path( __FILE__ ) . 'saavn-plugin.php';
include_once plugin_dir_path( __FILE__ ) . 'saavn-admin.php';
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-plugin-name-activator.php
 */
register_activation_hook(__FILE__,'pt_my_activation_function');
function pt_my_activation_function() {
	global $wpdb;	 
	$table_name = $wpdb->prefix . 'saavn';
	$charset_collate = $wpdb->get_charset_collate();
	$sql = "CREATE TABLE $table_name (
			  id int(11) NOT NULL AUTO_INCREMENT,
			  f_name varchar(255),
			  l_name varchar(255),
			  email varchar(255),
			  mobile varchar(255),
			  address varchar(255),
			  PRIMARY KEY id (id)
			 ) $charset_collate;";
	$result = $wpdb->query($sql); 
}
$pluginlog = plugin_dir_path(__FILE__).'debug.log';
$message = 'SOME ERROR'.PHP_EOL;
error_log($message, 3, $pluginlog);
?>