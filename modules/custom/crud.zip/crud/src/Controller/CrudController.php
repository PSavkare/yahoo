<?php
/**
 * @file
 * Contains \Drupal\crud\Controller\Tendersdisplay.
 */
namespace Drupal\crud\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;
use Drupal\taxonomy\Entity\Term;
use Drupal\node\NodeInterface;
use Drupal\Component\Utility;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\HttpFoundation\Request;
use Drupal\taxonomy\Entity;
use Drupal\taxonomy\TermInterface;
use Drupal\user\UserInterface;
/**
 * Class Display.
 *
 * @package Drupal\crud\Controller
 */
class CrudController extends ControllerBase {
  
  /**
  * showdata.
  *
  * @return string
  *   Return Table format data.
  */
  //Function To create node Programatically.
  public function create_new_node(){
    $node = Node::create(['type' => 'article']);
    $node->set('title', 'Heloo This is the Demo Tender content created programatically');
    //Body can now be an array with a value and a format.
    //If body field exists.
    $body = [
        'value' => 'Helooo, This is body content ',
        'format' => 'basic_html',
    ];
    $node->set('body', $body);
    $node->status = 1;
    $node->enforceIsNew();
    $node->save();
    drupal_set_message( "Node with nid " . $node->id() . " saved!\n");
    return array
    (
      '#markup' => '<p>Created node ID :'.$node->id().'</p><p> Node Title : '.$node->title->value.'</p><p>Node Body :'.$node->body->value,
    );
  }
  public function update_current_node(NodeInterface $node){
    $old_title = $node->title->value;
    $node->set("title","This is Updated Node Title");
    $old_body = $node->body->value;
    $node->set('body', "Updated body content");
    $node->save();
    return array
    (
      '#markup' => '<p>Created node ID :'.$node->id().'</p><p> Node Title : '.$old_title.'</p><p>Node Body :'.$old_body .'<p>Updated node ID :'.$node->id().'</p><p>Updated Node Title : '.$node->title->value.'</p><p>Updated Node Body :'.$node->body->value
    );
  }
  public function crud_save_image_local($url){
    echo $url;
    exit();
    $hash = md5($url);
    $dir = file_create_path('lastfm');
    if (!file_check_directory($dir)) {
      mkdir($dir, 0775, FALSE);
    }
    $hash = md5($url);
    $cachepath = file_create_path('customfiles/'. $hash.'.jpg');
    if (!is_file($cachepath)) {
      $result = eventpig_lastfm_fetch($url, $cachepath);
      if (!$result) {
        //we couldn't get the file
        return drupal_not_found();
      }
  }
  return array
    (
      '#markup' => file_directory_path() .'/customfiles/'. $hash.'.jpg',
    );
  }
  /**
  * Api function to fetch a url and save image locally
  */
  /*public function crud_fetch($url, $cachepath) {
    if (!$url) {
      return drupal_not_found();
    }
    $result = drupal_http_request($url);
    $code   = floor($result->code / 100) * 100;
    $types  = array('image/jpeg', 'image/png', 'image/gif');
    if ($result->data && $code != 400 && $code != 500 && in_array($result->Content-Type, $types)) {
      $src = file_save_data($result->data, $cachepath);
    }
    else  {
      return drupal_not_found();
    }
    return TRUE;
  }*/

  public function delete_single_node( NodeInterface $node)
  {
    $storage_handler = \Drupal::entityTypeManager()->getStorage("node");
    $storage_handler->delete(array($node));
    return array
    (
      '#markup' => 'Successfully Node Deleted Of ID :'.$node->id(),
    );
  }

  //Create User Programatically
  public function create_user(){
    $file_image='/var/www/html/drupal/sites/default/files/profile/placeholder.png';             
    $file_content = file_get_contents($file_image);
    $directory = 'public://Images/';
    file_prepare_directory($directory, FILE_CREATE_DIRECTORY);
    $file_image = file_save_data($file_content, $directory . basename($file_image),     FILE_EXISTS_REPLACE);
    $user = User::create([
            'name' =>'paurnima',    
            'mail' => 'paurnimaer@gmail.com',
            'pass' => 'password',
            'status' => 1,
            'roles' => array('editor','administrator'),
            'user_picture' => array('target_id' => $file_image->id()),
            'timezone'=> 'Indian/Christmas'
          ]);
    $user->save();
    return array
    (
      '#markup' => '<p>' . t('Created User ID:') .$user->id(). '</p>',
    );
  }
  public function update_user(UserInterface $user){
    $user->setPassword('string'); // string $password: The new unhashed password.
    $user->setEmail("vghsdhsdv@gmail.com"); // string $mail: The new email address of the user.
    $user->setUsername('raniii'); // string $username: The new user name.
    // Get a value to change. field_example_string_to_concatenate is the full machine name of the field.
    $user->save();
    return array
    (
      '#markup' => '<p>' . t('Updated User ID:') .$user->id(). '</p>',
    );
  }
  public function delete_user_account(UserInterface $user){
    $storage_handler = \Drupal::entityTypeManager()->getStorage("user");
    $storage_handler->delete(array($user));
    return array
    (
      '#markup' => '<p>Deleted user of User ID:'.$user->id().'</p>',
    );
  }
  public function add_taxonomy_term(){
    $term =Term::create([
          'name' => 'pune',
          'vid' => 'cities',
          ])
          ->save();
    return array
    (
      '#markup' => '<p>'.t('Taxonomy term Added Successfully:').$term.'</p>',
    );
  }
  public function delete_taxonomy_term(TermInterface $taxonomy_term){
    $storage_handler = \Drupal::entityTypeManager()->getStorage("taxonomy_term");
    $storage_handler->delete(array($taxonomy_term));
    return array
    (
      '#markup' => 'Successfully Node Deleted Of ID :'.$taxonomy_term,
    );
  }
}